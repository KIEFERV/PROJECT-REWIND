event_inherited();



// Trigger the shift on keypress
if (keyboard_check_pressed(ord("Z")) && time_phase == "present") {
    if (!rewind_active) {
        plr_travel_start();
    }
}

// Return condition is checked independently, on its own terms
if (time_phase == "past") {
    // Advance the replay head
   buffer_read_index = (buffer_read_index + 1) mod buffer_size;
    past_frames_elapsed++;
    if (past_frames_elapsed >= past_duration) { // actual catch-up condition 
        return_to_present();
    }
}


if (can_control) { //control logic (basic, probably will be phased out)
// Check for key presses
var left_key = keyboard_check(vk_left);
var right_key = keyboard_check(vk_right);
var up_key = keyboard_check(vk_up);
var down_key = keyboard_check(vk_down);

// Set movement speed
var move_speed = 4;

// Move the object based on key presses
if (left_key) {
    x -= move_speed;
}
if (right_key) {
    x += move_speed;
}
if (up_key) {
    y -= move_speed;
}
if (down_key) {
    y += move_speed;
} 

if (other.time_phase != time_phase) {
    exit; // ignore collision
}

}


//quick wallbreak test function

if (keyboard_check_pressed(ord("G")))  // press G to test
{
	
	show_debug_message("Time phase = " + time_phase);
	show_debug_message("return_to_present called, buffer_filled = " + string(buffer_filled));
    var wall = instance_nearest(x, y, oWallParent);
    
    if (wall != noone)
    {
        wall.take_damage(wall.wall_hp, DAMAGE_TYPE.BULLET);
    }
}

