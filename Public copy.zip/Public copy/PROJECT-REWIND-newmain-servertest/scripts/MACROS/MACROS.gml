//MACROS-- in essence, they replace a certain phrase/string throughout your code with whatever string/integer/variable you specify.
#macro FRAME_RATE 60 //in this macro, we replace any part of our code that says 'FRAME_RATE' with the integer 60.
#macro TILE_SIZE 16
#macro CARDINAL_DIR round(direction/90)
#macro ROOM_START TestRoom1
#macro RESOLUTION_W 360
#macro RESOLUTION_H 180

//Positions


//Rewind
#macro REWIND_SPEED 5
#macro TIME_TRAVEL_DURATION 5