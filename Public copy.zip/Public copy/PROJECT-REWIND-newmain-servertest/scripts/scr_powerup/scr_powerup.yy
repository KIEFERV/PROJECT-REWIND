{
  "$GMScript":"v1",
  "%Name":"scr_powerup",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_powerup",
  "parent":{
    "name":"scr_scripts",
    "path":"folders/Scripts/Rewind Scripts/scr_scripts.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}